package com.example.newass;

import junit.framework.TestCase;

public class ProgressBarAnimation extends TestCase {

}