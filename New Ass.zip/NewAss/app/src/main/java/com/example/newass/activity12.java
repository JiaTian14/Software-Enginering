package com.example.newass;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class activity12 extends AppCompatActivity {

    public Button button;
    private EditText Password2;
    private Button DoneButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity12);

        Password2= findViewById(R.id.Password2);
        DoneButton = findViewById(R.id.DoneButton);

        DoneButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Validate if fields are not empty
                if (isValidInput()) {
                    // Process the form dat
                    String password2 = Password2.getText().toString();
                    // Do something with the data (e.g., save to database)
                    Toast.makeText(activity12.this, "Password2: " + password2 , Toast.LENGTH_SHORT).show();
                } else {
                    // Show an error message if fields are empty
                    Toast.makeText(activity12.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean isValidInput() {
        button = (Button) findViewById(R.id.DoneButton);

        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(activity12.this, activity8. class);
                startActivity(intent);
            }
        });
        return false;
    }
}