package com.example.newass;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class activity11 extends AppCompatActivity {
    public Button button;
    private EditText OTPPassword;
    private Button SendButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity11);



        button = (Button) findViewById(R.id.Back);

        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(activity11.this, activity10. class);
                startActivity(intent);
            }
        });

        OTPPassword = findViewById(R.id.OTPPassword);
        SendButton = findViewById(R.id.SendButton);

        SendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Validate if fields are not empty
                if (isValidInput()) {
                    // Process the form dat
                    String otppassword = OTPPassword.getText().toString();
                    // Do something with the data (e.g., save to database)
                    Toast.makeText(activity11.this, "OTPPassword: " + otppassword , Toast.LENGTH_SHORT).show();
                } else {
                    // Show an error message if fields are empty
                    Toast.makeText(activity11.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean isValidInput() {
        button = (Button) findViewById(R.id.SendButton);

        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(activity11.this, activity12. class);
                startActivity(intent);
            }
        });
        return false;
    }
}