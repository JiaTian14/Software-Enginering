package com.example.newass;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class activity9 extends AppCompatActivity {
public Button button;
    private EditText EmailAddress;
    private EditText Username;
    private EditText Phone;
    private EditText Password;
    private Button SignUpButton;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity9);

        button = (Button) findViewById(R.id.LoginAccountButton);

        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(activity9.this, activity8. class);
                startActivity(intent);
            }
        });



        EmailAddress = findViewById(R.id.EmailAddress);
        Username = findViewById(R.id.Username);
        Phone = findViewById(R.id.Phone);
        Password = findViewById(R.id.Password);
        SignUpButton = findViewById(R.id.SignUpButton);

        SignUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Validate if fields are not empty
                if (isValidInput()) {
                    // Process the form dat
                    String email = EmailAddress.getText().toString();
                    String username = Username.getText().toString();
                    String phone = Phone.getText().toString();
                    String password = Password.getText().toString();
                    // Do something with the data (e.g., save to database)
                    Toast.makeText(activity9.this, "Email: " + email + "\nUsername: " + username+ "\nPhone: " + phone + "\nPassword: " + password , Toast.LENGTH_SHORT).show();
                } else {
                    // Show an error message if fields are empty
                    Toast.makeText(activity9.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean isValidInput() {
        button = (Button) findViewById(R.id.SignUpButton);

        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(activity9.this, activity8. class);
                startActivity(intent);
            }
        });
        return false;
    }
}