package com.example.newass;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class activity3 extends AppCompatActivity {
public Button button;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity3);

        button = (Button) findViewById(R.id.button1);

        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(activity3.this, activity6. class);
                startActivity(intent);
            }
        });


        button = (Button) findViewById(R.id.button2);

        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(activity3.this, activity6. class);
                startActivity(intent);
            }
        });


        button = (Button) findViewById(R.id.button3);

        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(activity3.this, activity6. class);
                startActivity(intent);
            }
        });


        button = (Button) findViewById(R.id.button4);

        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(activity3.this, activity6. class);
                startActivity(intent);
            }
        });


        button = (Button) findViewById(R.id.button5);

        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(activity3.this, activity6. class);
                startActivity(intent);
            }
        });


        button = (Button) findViewById(R.id.button6);

        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(activity3.this, activity6. class);
                startActivity(intent);
            }
        });


        button = (Button) findViewById(R.id.button7);

        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(activity3.this, activity6. class);
                startActivity(intent);
            }
        });


        button = (Button) findViewById(R.id.button8);

        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(activity3.this, activity6. class);
                startActivity(intent);
            }
        });


        button = (Button) findViewById(R.id.button9);

        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(activity3.this, activity6. class);
                startActivity(intent);
            }
        });


        button = (Button) findViewById(R.id.button10);

        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(activity3.this, activity6. class);
                startActivity(intent);
            }
        });


        button = (Button) findViewById(R.id.button11);

        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(activity3.this, activity6. class);
                startActivity(intent);
            }
        });


        button = (Button) findViewById(R.id.button12);

        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(activity3.this, activity6. class);
                startActivity(intent);
            }
        });


        button = (Button) findViewById(R.id.button13);

        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(activity3.this, activity6. class);
                startActivity(intent);
            }
        });


        button = (Button) findViewById(R.id.button14);

        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(activity3.this, activity6. class);
                startActivity(intent);
            }
        });


        button = (Button) findViewById(R.id.button15);

        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(activity3.this, activity6. class);
                startActivity(intent);
            }
        });


        button = (Button) findViewById(R.id.button16);

        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(activity3.this, activity6. class);
                startActivity(intent);
            }
        });

        button = (Button) findViewById(R.id.Back);

        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(activity3.this, activity2. class);
                startActivity(intent);
            }
        });

    }
}